"""Authenticated CommerceDesk business API."""
